import styles from "../components/styles/LeftBar.module.css";

export default function RightBar(){
    return <div className={styles.playerList}></div>
}